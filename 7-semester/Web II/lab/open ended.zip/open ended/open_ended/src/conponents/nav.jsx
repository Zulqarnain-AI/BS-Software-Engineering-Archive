import React from "react";

export default function Nav() {
    return (
        <nav aria-label="Main navigation">
            <ul style={{ display: "flex", gap: 16, listStyle: "none", margin: 0, padding: 0 }}>
                <li>
                    <a href="/sourses">Sourses</a>
                </li>
                <li>
                    <a href="/participatants">Participatants</a>
                </li>
            </ul>
        </nav>
    );
}